package com.lwj.mybatis.mapper;

import com.lwj.easymybatis.common.CommonMaper;
import com.lwj.mybatis.entity.Customerad;

public interface CustomeradMapper extends CommonMaper<Customerad> {
}