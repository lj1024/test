package com.lwj.flow.cert.mapper;

import com.lwj.easymybatis.common.CommonMaper;
import com.lwj.flow.cert.entity.Certificate;

public interface CertificateMapper extends CommonMaper<Certificate> {
}