package com.lwj.flow.cert.mapper;

import com.lwj.easymybatis.common.CommonMaper;
import com.lwj.flow.cert.entity.Employee;

public interface EmployeeMapper extends CommonMaper<Employee> {
}