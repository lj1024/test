package com.lwj.flow.login.entity;

public class RoleResources {
    /**
     * 
     *
     * 
     */
    private Integer roleid;

    /**
     * 
     *
     * 
     */
    private Integer resourcesid;

    /**
     *
     * 
     */
    public Integer getRoleid() {
        return roleid;
    }

    /**
     *
     * 
     */
    public void setRoleid(Integer roleid) {
        this.roleid = roleid;
    }

    /**
     *
     * 
     */
    public Integer getResourcesid() {
        return resourcesid;
    }

    /**
     *
     * 
     */
    public void setResourcesid(Integer resourcesid) {
        this.resourcesid = resourcesid;
    }
}