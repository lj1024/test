package com.lwj.flow.login.mapper;

import com.lwj.easymybatis.common.CommonMaper;
import com.lwj.flow.login.entity.UserRole;

public interface UserRoleMapper extends CommonMaper<UserRole> {
}