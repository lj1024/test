 Vue.prototype.handleSelect = function (key,keyPath){
	 console.log(key,keyPath);
	 window.location.href=key;
 };