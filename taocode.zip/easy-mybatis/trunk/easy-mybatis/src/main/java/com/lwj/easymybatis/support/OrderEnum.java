/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.easymybatis.support;
/**
 * 类注释
 *
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2015年10月8日 下午5:58:57
 * @since JDK1.7+
 */
public enum OrderEnum {
    ASC,DESC;
}
