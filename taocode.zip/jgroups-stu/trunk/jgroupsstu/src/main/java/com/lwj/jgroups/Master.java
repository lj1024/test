package com.lwj.jgroups;

/**
 * @author Bela Ban
 */
public interface Master {
    Object submit(Task task, long timeout) throws Exception;
}
