/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.jgroups;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;

import org.jgroups.JChannel;
import org.jgroups.Message;
import org.jgroups.ReceiverAdapter;
import org.jgroups.View;
import org.jgroups.util.Util;

/**
 * 类注释
 * 
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2016年6月24日 上午10:45:11
 * @since JDK1.7+
 */
public class SimpleChat extends ReceiverAdapter  {

	JChannel jChannel;

	String userName = System.getProperty("user.name", "N/A");
	final List<String> state=new LinkedList<String>();

	public void start() throws Exception {
		jChannel = new JChannel().name("B");
		jChannel.setReceiver(this);
		jChannel.connect("ChatCluster");
		jChannel.getState(null, 10000);
		eventLoop();
		jChannel.close();
	}

	private void eventLoop() {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			try {
				System.out.print("> ");
				System.out.flush();
				String line = in.readLine().toLowerCase();
				if (line.startsWith("quit") || line.startsWith("exit"))
					break;
				line = "[" + userName + "] " + line;
				Message msg = new Message(null, null, line);
				jChannel.send(msg);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void viewAccepted(View new_view) {
	    System.out.println("** view: " + new_view);
	}

	public void receive(Message msg) {
		String line=msg.getSrc() + ": " + msg.getObject();
	    System.out.println(line);
	    synchronized(state) {
	        state.add(line);
	    }
	}
	
	public void setState(InputStream input) throws Exception {
	    List<String> list;
	    list=(List<String>)Util.objectFromStream(new DataInputStream(input));
	    synchronized(state) {
	        state.clear();
	        state.addAll(list);
	    }
	    System.out.println(list.size() + " messages in chat history):");
	    for(String str: list) {
	        System.out.println(str);
	    }
	}
	
	
	public void getState(OutputStream output) throws Exception {
	    synchronized(state) {
	        Util.objectToStream(state, new DataOutputStream(output));
	    }
	}

	public static void main(String[] args) throws Exception {
		new SimpleChat().start();
	}

}
