package com.lwj.jgroups;

/**
 * @author Bela Ban
 */
public interface Slave {
    Object handle(Task task);
}
