/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.nettystu.chapter02.point02;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 类注释
 *
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2016年6月3日 上午11:03:26
 * @since JDK1.7+
 */
public class AIOServer {
	static int PORT = 30000;
	static String UTF_8="utf-8";
	static List<AsynchronousSocketChannel> channelList = new ArrayList<>();
	
	public void startListen() throws IOException{
		ExecutorService executor = Executors.newFixedThreadPool(20);
		AsynchronousChannelGroup group = AsynchronousChannelGroup.withThreadPool(executor);
		AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open(group).bind(new InetSocketAddress(PORT));
			serverChannel.accept(null, new ActionHandler(serverChannel));
			try {
				Thread.sleep(Integer.MAX_VALUE);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	public static void main(String[] args) throws IOException {
		new AIOServer().startListen();
	}
	
	

}

class ActionHandler implements CompletionHandler<AsynchronousSocketChannel, Object> {

	private AsynchronousServerSocketChannel serverChannel;
	
	public ActionHandler(AsynchronousServerSocketChannel serverChannel) {
		super();
		this.serverChannel = serverChannel;
	}
	ByteBuffer buff = ByteBuffer.allocate(1024);

	@Override
	public void completed(final AsynchronousSocketChannel sc, Object attachment) {
         AIOServer.channelList.add(sc);	
         serverChannel.accept(null, this);
         sc.read(buff, null, new CompletionHandler<Integer, Object>() {

			@Override
			public void completed(Integer result, Object attachment) {
				buff.flip();
				String content = StandardCharsets.UTF_8.decode(buff).toString();
				for(AsynchronousSocketChannel c : AIOServer.channelList) {
					try {
						c.write(ByteBuffer.wrap(content.getBytes(AIOServer.UTF_8))).get();
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
				}
				buff.clear();
				sc.read(buff, null, this);
			}

			@Override
			public void failed(Throwable exc, Object attachment) {
				System.out.println("读取数据失败:"+exc);
				AIOServer.channelList.remove(sc);
			}
		});
	}

	@Override
	public void failed(Throwable exc, Object attachment) {
       System.out.println("连接失败:"+exc);		
	}
	
}
