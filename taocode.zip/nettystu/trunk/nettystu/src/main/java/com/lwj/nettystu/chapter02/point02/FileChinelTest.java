/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.nettystu.chapter02.point02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

/**
 * 类注释
 *
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2016年6月2日 下午4:17:18
 * @since JDK1.7+
 */
public class FileChinelTest {

	public static void main(String[] args) throws IOException {
		File file = new File("D:\\test.txt");
		System.out.println(file.length());
		FileChannel inFileChannel = new FileInputStream(file).getChannel();
		FileChannel outFileChannel = new FileOutputStream(file).getChannel();
		MappedByteBuffer mapByteBuf =  inFileChannel.map(MapMode.READ_ONLY, 0, file.length());
		System.out.println(mapByteBuf.capacity()+" " +mapByteBuf.position()+" "+mapByteBuf.limit());
		outFileChannel.write(mapByteBuf);
		mapByteBuf.clear();
		Charset charset = Charset.forName("UTF-8");
		CharsetDecoder charDec = charset.newDecoder();
		CharBuffer charBuf = charDec.decode(mapByteBuf);
		System.out.println(charBuf);
		

		

	}

}
