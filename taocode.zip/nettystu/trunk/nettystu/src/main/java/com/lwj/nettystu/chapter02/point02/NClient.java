/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.nettystu.chapter02.point02;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Scanner;

/**
 * 类注释
 * 
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2016年6月3日 上午10:08:05
 * @since JDK1.7+
 */
public class NClient {

	private Selector selector = null;

	static final int PORT = 30000;

	private Charset charSet = Charset.forName("UTF-8");

	private SocketChannel sc = null;

	public void init() throws IOException {
		selector = Selector.open();
		InetSocketAddress isa = new InetSocketAddress("127.0.0.1", PORT);
		sc = SocketChannel.open(isa);
		sc.configureBlocking(false);
		sc.register(selector, SelectionKey.OP_READ);
		new ClientThread().start();
		Scanner scan = new Scanner(System.in);
		while(scan.hasNextLine()) {
			String line = scan.nextLine();
			sc.write(charSet.encode(line));
		}

	}

	public static void main(String[] args) throws IOException {
            new NClient().init();
	}

	private class ClientThread extends Thread {
		public void run() {
			try {
				while (selector.select() > 0) {

					for (SelectionKey sk : selector.selectedKeys()) {
						selector.selectedKeys().remove(sk);
						if (sk.isReadable()) {
							SocketChannel sc = (SocketChannel) sk.channel();
							ByteBuffer buff = ByteBuffer.allocate(1024);
							String content = "";
							while (sc.read(buff) > 0) {
								sc.read(buff);
								buff.flip();
								content = content + charSet.decode(buff);
							}
							System.out.println("聊天信息:" + content);
							sk.interestOps(SelectionKey.OP_READ);
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

}
