/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.nettystu.chapter02.point02;

import java.io.IOException;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 类注释
 *
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2016年6月2日 下午4:49:52
 * @since JDK1.7+
 */
public class PathsTest {

	public static void main(String[] args) throws IOException {
		
		Path  path = Paths.get(".");
		System.out.println(path.getNameCount());
		System.out.println(path.getRoot());
		Path abslutePath = path.toAbsolutePath();
		System.out.println(abslutePath);
		System.out.println(abslutePath.getRoot());
		System.out.println(abslutePath.getNameCount());
		System.out.println(abslutePath.getName(2));
		Path path2 =  Paths.get("C:", "abc","123");
		System.out.println(path2);
		
		FileStore fileStore = Files.getFileStore(Paths.get("c:"));
		System.out.println(fileStore.getTotalSpace()+fileStore.getUsableSpace());
		

	}

}
