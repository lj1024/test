/*
 * 公司:北龙中网（北京）科技有限责任公司	网址:http://www.knet.cn
 * 
 */
package com.lwj.nettystu.chapter02.point03;
/**
 * 类注释
 *
 * @author <a href="mailto:luwenjie@knet.cn">芦文杰</a>
 * @version 2016年6月2日 下午1:11:41
 * @since JDK1.7+
 */
public class MultiplexerTimeServer implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
